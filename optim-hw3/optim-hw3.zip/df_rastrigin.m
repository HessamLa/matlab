function df = df_rastrigin(x1,x2)
df =  [(x1/50) + 2*pi*sin(pi*x1/5);
       (x2/50) + 2*pi*sin(pi*x2/5)] ;
